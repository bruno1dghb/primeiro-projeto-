function setup() {
  createCanvas(400, 400);
  background(220); // Define o fundo como um cinza claro
}

function draw() {
  // Desenha um círculo vermelho com borda preta
  fill("red");
  stroke("black");
  circle(50, 50, 80);

  // Desenha um quadrado azul com borda verde
  fill(0, 0, 255); // Azul em RGB
  stroke("green");
  rect(150, 50, 80, 80);
}